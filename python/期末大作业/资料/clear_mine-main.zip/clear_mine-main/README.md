# clear_mine
this is a little game
